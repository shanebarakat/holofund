'use strict';

const testContract = require('./logic');

module.exports.contracts = [ testContract ];
